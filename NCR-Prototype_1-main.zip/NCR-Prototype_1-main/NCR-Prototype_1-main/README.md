### This is an NCR website (PROTOTYPE 1) that is used to track the defective products that consumer got.
### This website will track the NCR report that the Quality assurance person will generate for that product, then it will be passed to the engineer and then to the purchasing department.

